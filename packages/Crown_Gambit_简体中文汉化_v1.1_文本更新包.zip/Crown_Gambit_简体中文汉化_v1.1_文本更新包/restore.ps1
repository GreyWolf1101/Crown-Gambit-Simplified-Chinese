$ErrorActionPreference = 'Stop'
$PreviousHashes = @(
    '8E1B89FBF9F1E0ADE2D704B049D2EF7AEFDB1574DFCDD01AAFC7EA8988AC7C1E',
    '30935B8591888ADDC09144E79C135925A06F6CC6D0C2594A7E175F23C3AF1472'
)
function Find-GameDirectory {
    $candidate = $PSScriptRoot
    for ($depth = 0; $depth -lt 6 -and $candidate; $depth++) {
        if (Test-Path -LiteralPath (Join-Path $candidate 'crown_gambit_windows.exe')) { return $candidate }
        $candidate = Split-Path -Parent $candidate
    }
    throw 'Game directory not found.'
}
if (Get-Process -Name 'crown_gambit_windows' -ErrorAction SilentlyContinue) { throw 'Close Crown Gambit first.' }
$GameDirectory = Find-GameDirectory
$GamePck = Join-Path $GameDirectory 'crown_gambit_windows.pck'
$Backup = Join-Path $GameDirectory 'crown_gambit_windows.before_text_v1.1.pck'
if (-not (Test-Path -LiteralPath $Backup)) { throw "Update backup not found: $Backup" }
$BackupHash = (Get-FileHash -LiteralPath $Backup -Algorithm SHA256).Hash
if ($BackupHash -notin $PreviousHashes) { throw "Backup hash is unexpected: $BackupHash" }
Copy-Item -LiteralPath $Backup -Destination $GamePck -Force
Write-Host 'The pre-update localized version has been restored.' -ForegroundColor Green
