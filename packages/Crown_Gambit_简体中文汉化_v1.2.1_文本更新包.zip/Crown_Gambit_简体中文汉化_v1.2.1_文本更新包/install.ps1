$ErrorActionPreference = 'Stop'

$UpgradeStages = @{
    '8E1B89FBF9F1E0ADE2D704B049D2EF7AEFDB1574DFCDD01AAFC7EA8988AC7C1E' = @{ Patch = 'crown_gambit_zh_v1_text_update.xdelta'; Result = '2C2495AA91C179BC8BA932D4CDFBC070A5FC776C520086AB75BAC011714B6AC0' }
    '30935B8591888ADDC09144E79C135925A06F6CC6D0C2594A7E175F23C3AF1472' = @{ Patch = 'crown_gambit_zh_v11_from_309.xdelta'; Result = '2C2495AA91C179BC8BA932D4CDFBC070A5FC776C520086AB75BAC011714B6AC0' }
    '460F7A199E39271DB54D6C838805395594F7974A419E066344DBDACCBD34BEA2' = @{ Patch = 'crown_gambit_zh_v11_from_460f.xdelta'; Result = '2C2495AA91C179BC8BA932D4CDFBC070A5FC776C520086AB75BAC011714B6AC0' }
    '2C2495AA91C179BC8BA932D4CDFBC070A5FC776C520086AB75BAC011714B6AC0' = @{ Patch = 'crown_gambit_zh_v12_from_2c24.xdelta'; Result = 'CCEEAF30DC3A3F7E9689AD6539C12C377895087E91E4B6E887B2756E7EDA0638' }
    '9204853CB81F7C452EEF51405974A7CDD6E5E1A39B35215717DE7F3D418B13CA' = @{ Patch = 'crown_gambit_zh_v12_from_9204.xdelta'; Result = 'CCEEAF30DC3A3F7E9689AD6539C12C377895087E91E4B6E887B2756E7EDA0638' }
    'EA99DC9E806233CDA7AE2CDE2718FE0546D4DE753862C8E2D92E202F6E0B9AB5' = @{ Patch = 'crown_gambit_zh_v12_from_ea99.xdelta'; Result = 'CCEEAF30DC3A3F7E9689AD6539C12C377895087E91E4B6E887B2756E7EDA0638' }
    'CCEEAF30DC3A3F7E9689AD6539C12C377895087E91E4B6E887B2756E7EDA0638' = @{ Patch = 'crown_gambit_zh_v121_from_v12.xdelta'; Result = '407482D0B0F5F049892C297853684961B683B6A7DF1A5F33AF0C0A9952F21D60' }
}
$FinalHash = '407482D0B0F5F049892C297853684961B683B6A7DF1A5F33AF0C0A9952F21D60'
$Tool = Join-Path $PSScriptRoot 'tools\xdelta3.exe'

function Find-GameDirectory {
    $candidate = $PSScriptRoot
    for ($depth = 0; $depth -lt 6 -and $candidate; $depth++) {
        if (Test-Path -LiteralPath (Join-Path $candidate 'crown_gambit_windows.exe')) { return $candidate }
        $candidate = Split-Path -Parent $candidate
    }
    throw 'Game directory not found. Extract this package into the Crown Gambit game directory.'
}

function Apply-XdeltaPatch {
    param([string]$Source, [string]$Patch, [string]$Destination)
    & $Tool -d -f -s $Source $Patch $Destination
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $Destination)) {
        throw "xdelta3 failed with exit code $LASTEXITCODE."
    }
}

if (Get-Process -Name 'crown_gambit_windows' -ErrorAction SilentlyContinue) {
    throw 'Crown Gambit is running. Close the game before installing.'
}

$GameDirectory = Find-GameDirectory
$GamePck = Join-Path $GameDirectory 'crown_gambit_windows.pck'
$Backup = Join-Path $GameDirectory 'crown_gambit_windows.before_text_v1.2.1.pck'
$TemporaryPaths = @(
    (Join-Path $GameDirectory 'crown_gambit_windows.v121_stage_a.tmp'),
    (Join-Path $GameDirectory 'crown_gambit_windows.v121_stage_b.tmp')
)

if (-not (Test-Path -LiteralPath $GamePck)) { throw 'crown_gambit_windows.pck was not found.' }
if (-not (Test-Path -LiteralPath $Tool)) { throw 'The bundled xdelta3 tool is missing.' }

$CurrentHash = (Get-FileHash -LiteralPath $GamePck -Algorithm SHA256).Hash
if ($CurrentHash -eq $FinalHash) {
    Write-Host 'The v1.2.1 localization is already installed.' -ForegroundColor Green
    exit 0
}
if (-not $UpgradeStages.ContainsKey($CurrentHash)) {
    throw "This updater requires a supported earlier localized PCK, found $CurrentHash. Vanilla users must install the complete package."
}

$StageCount = 0
$ProbeHash = $CurrentHash
while ($ProbeHash -ne $FinalHash) {
    if (-not $UpgradeStages.ContainsKey($ProbeHash)) { throw "No upgrade path from $ProbeHash." }
    $ProbeHash = $UpgradeStages[$ProbeHash].Result
    $StageCount++
    if ($StageCount -gt 10) { throw 'Invalid upgrade stage loop.' }
}

$DriveName = [IO.Path]::GetPathRoot($GameDirectory).TrimEnd('\').TrimEnd(':')
$Drive = Get-PSDrive -Name $DriveName
$TemporaryCopies = if ($StageCount -gt 1) { 2 } else { 1 }
$Required = ((Get-Item -LiteralPath $GamePck).Length * $TemporaryCopies) + 1GB
if ($Drive.Free -lt $Required) {
    throw ('Not enough free disk space. At least {0:N1} GB is required during installation.' -f ($Required / 1GB))
}

foreach ($temporary in $TemporaryPaths) {
    if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force }
}
if (-not (Test-Path -LiteralPath $Backup)) {
    try {
        New-Item -ItemType HardLink -Path $Backup -Target $GamePck -ErrorAction Stop | Out-Null
    } catch {
        if ($Drive.Free -lt ($Required + (Get-Item -LiteralPath $GamePck).Length)) {
            throw 'The backup could not use a hard link, and there is not enough free space to copy it.'
        }
        Copy-Item -LiteralPath $GamePck -Destination $Backup
    }
}
$BackupHash = (Get-FileHash -LiteralPath $Backup -Algorithm SHA256).Hash
if ($BackupHash -ne $CurrentHash) { throw "Existing update backup hash is unexpected: $BackupHash" }

$Source = $GamePck
$SourceHash = $CurrentHash
$StageIndex = 0
try {
    while ($SourceHash -ne $FinalHash) {
        $Stage = $UpgradeStages[$SourceHash]
        $Patch = Join-Path $PSScriptRoot (Join-Path 'patch' $Stage.Patch)
        $Destination = $TemporaryPaths[$StageIndex % 2]
        if (-not (Test-Path -LiteralPath $Patch)) { throw "Required patch is missing: $($Stage.Patch)" }
        if (Test-Path -LiteralPath $Destination) { Remove-Item -LiteralPath $Destination -Force }

        Write-Host "Applying localization update stage $($StageIndex + 1) of $StageCount..."
        Apply-XdeltaPatch -Source $Source -Patch $Patch -Destination $Destination
        $BuiltHash = (Get-FileHash -LiteralPath $Destination -Algorithm SHA256).Hash
        if ($BuiltHash -ne $Stage.Result) {
            throw "Stage verification failed. Expected $($Stage.Result), built $BuiltHash."
        }

        if ($Source -ne $GamePck -and (Test-Path -LiteralPath $Source)) {
            Remove-Item -LiteralPath $Source -Force
        }
        $Source = $Destination
        $SourceHash = $BuiltHash
        $StageIndex++
    }

    Move-Item -LiteralPath $Source -Destination $GamePck -Force
} finally {
    foreach ($temporary in $TemporaryPaths) {
        if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force }
    }
}

Write-Host 'The v1.2.1 text update was installed successfully.' -ForegroundColor Green
