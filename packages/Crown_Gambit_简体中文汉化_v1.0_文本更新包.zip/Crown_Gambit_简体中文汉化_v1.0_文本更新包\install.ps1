$ErrorActionPreference = 'Stop'
$PreviousHash = '552271BD0F6592B9ECC3FEA041A7E26FFC761A82ACF8F2F1296721D9F0F2A87F'
$FinalHash = '30935B8591888ADDC09144E79C135925A06F6CC6D0C2594A7E175F23C3AF1472'
$Tool = Join-Path $PSScriptRoot 'tools\xdelta3.exe'
$Patch = Join-Path $PSScriptRoot 'patch\crown_gambit_zh_v1_text_update.xdelta'

function Find-GameDirectory {
    $candidate = $PSScriptRoot
    for ($depth = 0; $depth -lt 6 -and $candidate; $depth++) {
        if (Test-Path -LiteralPath (Join-Path $candidate 'crown_gambit_windows.exe')) { return $candidate }
        $candidate = Split-Path -Parent $candidate
    }
    throw 'Game directory not found. Extract this package into the Crown Gambit game directory.'
}

if (Get-Process -Name 'crown_gambit_windows' -ErrorAction SilentlyContinue) {
    throw 'Crown Gambit is running. Close the game before installing.'
}
$GameDirectory = Find-GameDirectory
$GamePck = Join-Path $GameDirectory 'crown_gambit_windows.pck'
$Backup = Join-Path $GameDirectory 'crown_gambit_windows.before_text_v1.0.pck'
$Temporary = Join-Path $GameDirectory 'crown_gambit_windows.text_installing.tmp'
if (-not (Test-Path -LiteralPath $GamePck)) { throw 'crown_gambit_windows.pck was not found.' }
if (-not (Test-Path -LiteralPath $Tool)) { throw 'The bundled xdelta3 tool is missing.' }
if (-not (Test-Path -LiteralPath $Patch)) { throw 'The text update patch is missing.' }
$CurrentHash = (Get-FileHash -LiteralPath $GamePck -Algorithm SHA256).Hash
if ($CurrentHash -eq $FinalHash) {
    Write-Host 'The latest text is already installed.' -ForegroundColor Green
    exit 0
}
if ($CurrentHash -ne $PreviousHash) {
    throw "This updater requires the previous complete localization ($PreviousHash), found $CurrentHash. Vanilla users must install the complete package."
}
$DriveName = [IO.Path]::GetPathRoot($GameDirectory).TrimEnd('\').TrimEnd(':')
$Drive = Get-PSDrive -Name $DriveName
$Required = (Get-Item -LiteralPath $GamePck).Length + 1GB
if ($Drive.Free -lt $Required) {
    throw ('Not enough free disk space. At least {0:N1} GB is required during installation.' -f ($Required / 1GB))
}
if (Test-Path -LiteralPath $Temporary) { Remove-Item -LiteralPath $Temporary -Force }
if (-not (Test-Path -LiteralPath $Backup)) {
    try {
        New-Item -ItemType HardLink -Path $Backup -Target $GamePck -ErrorAction Stop | Out-Null
    } catch {
        if ($Drive.Free -lt ($Required + (Get-Item -LiteralPath $GamePck).Length)) {
            throw 'The backup could not use a hard link, and there is not enough free space to copy it.'
        }
        Copy-Item -LiteralPath $GamePck -Destination $Backup
    }
}
$BackupHash = (Get-FileHash -LiteralPath $Backup -Algorithm SHA256).Hash
if ($BackupHash -ne $PreviousHash) { throw "Existing update backup hash is unexpected: $BackupHash" }
Write-Host 'Applying the full-chapter text update...'
& $Tool -d -f -s $GamePck $Patch $Temporary
if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $Temporary)) {
    if (Test-Path -LiteralPath $Temporary) { Remove-Item -LiteralPath $Temporary -Force }
    throw "xdelta3 failed with exit code $LASTEXITCODE."
}
$BuiltHash = (Get-FileHash -LiteralPath $Temporary -Algorithm SHA256).Hash
if ($BuiltHash -ne $FinalHash) {
    Remove-Item -LiteralPath $Temporary -Force
    throw "Verification failed. Expected $FinalHash, built $BuiltHash."
}
Move-Item -LiteralPath $Temporary -Destination $GamePck -Force
Write-Host 'Text update installed successfully.' -ForegroundColor Green
