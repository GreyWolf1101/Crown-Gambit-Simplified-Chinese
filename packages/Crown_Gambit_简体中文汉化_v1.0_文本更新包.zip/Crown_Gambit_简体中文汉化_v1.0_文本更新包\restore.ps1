$ErrorActionPreference = 'Stop'
$PreviousHash = '552271BD0F6592B9ECC3FEA041A7E26FFC761A82ACF8F2F1296721D9F0F2A87F'
function Find-GameDirectory {
    $candidate = $PSScriptRoot
    for ($depth = 0; $depth -lt 6 -and $candidate; $depth++) {
        if (Test-Path -LiteralPath (Join-Path $candidate 'crown_gambit_windows.exe')) { return $candidate }
        $candidate = Split-Path -Parent $candidate
    }
    throw 'Game directory not found.'
}
if (Get-Process -Name 'crown_gambit_windows' -ErrorAction SilentlyContinue) { throw 'Close Crown Gambit first.' }
$GameDirectory = Find-GameDirectory
$GamePck = Join-Path $GameDirectory 'crown_gambit_windows.pck'
$Backup = Join-Path $GameDirectory 'crown_gambit_windows.before_text_v1.0.pck'
if (-not (Test-Path -LiteralPath $Backup)) { throw "Update backup not found: $Backup" }
$BackupHash = (Get-FileHash -LiteralPath $Backup -Algorithm SHA256).Hash
if ($BackupHash -ne $PreviousHash) { throw "Backup hash is unexpected: $BackupHash" }
Copy-Item -LiteralPath $Backup -Destination $GamePck -Force
Write-Host 'The pre-update localized version has been restored.' -ForegroundColor Green
