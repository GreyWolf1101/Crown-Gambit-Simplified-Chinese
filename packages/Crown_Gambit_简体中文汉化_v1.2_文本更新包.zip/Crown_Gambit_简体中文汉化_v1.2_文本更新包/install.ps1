$ErrorActionPreference = 'Stop'

$BridgePatches = @{
    '8E1B89FBF9F1E0ADE2D704B049D2EF7AEFDB1574DFCDD01AAFC7EA8988AC7C1E' = 'crown_gambit_zh_v1_text_update.xdelta'
    '30935B8591888ADDC09144E79C135925A06F6CC6D0C2594A7E175F23C3AF1472' = 'crown_gambit_zh_v11_from_309.xdelta'
    '460F7A199E39271DB54D6C838805395594F7974A419E066344DBDACCBD34BEA2' = 'crown_gambit_zh_v11_from_460f.xdelta'
}
$DirectPatches = @{
    '2C2495AA91C179BC8BA932D4CDFBC070A5FC776C520086AB75BAC011714B6AC0' = 'crown_gambit_zh_v12_from_2c24.xdelta'
    '9204853CB81F7C452EEF51405974A7CDD6E5E1A39B35215717DE7F3D418B13CA' = 'crown_gambit_zh_v12_from_9204.xdelta'
    'EA99DC9E806233CDA7AE2CDE2718FE0546D4DE753862C8E2D92E202F6E0B9AB5' = 'crown_gambit_zh_v12_from_ea99.xdelta'
}
$IntermediateHash = '2C2495AA91C179BC8BA932D4CDFBC070A5FC776C520086AB75BAC011714B6AC0'
$FinalHash = 'CCEEAF30DC3A3F7E9689AD6539C12C377895087E91E4B6E887B2756E7EDA0638'
$Tool = Join-Path $PSScriptRoot 'tools\xdelta3.exe'

function Find-GameDirectory {
    $candidate = $PSScriptRoot
    for ($depth = 0; $depth -lt 6 -and $candidate; $depth++) {
        if (Test-Path -LiteralPath (Join-Path $candidate 'crown_gambit_windows.exe')) { return $candidate }
        $candidate = Split-Path -Parent $candidate
    }
    throw 'Game directory not found. Extract this package into the Crown Gambit game directory.'
}

function Apply-XdeltaPatch {
    param([string]$Source, [string]$Patch, [string]$Destination)
    & $Tool -d -f -s $Source $Patch $Destination
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $Destination)) {
        throw "xdelta3 failed with exit code $LASTEXITCODE."
    }
}

if (Get-Process -Name 'crown_gambit_windows' -ErrorAction SilentlyContinue) {
    throw 'Crown Gambit is running. Close the game before installing.'
}

$GameDirectory = Find-GameDirectory
$GamePck = Join-Path $GameDirectory 'crown_gambit_windows.pck'
$Backup = Join-Path $GameDirectory 'crown_gambit_windows.before_text_v1.2.pck'
$BridgeTemporary = Join-Path $GameDirectory 'crown_gambit_windows.v12_bridge.tmp'
$FinalTemporary = Join-Path $GameDirectory 'crown_gambit_windows.v12_installing.tmp'

if (-not (Test-Path -LiteralPath $GamePck)) { throw 'crown_gambit_windows.pck was not found.' }
if (-not (Test-Path -LiteralPath $Tool)) { throw 'The bundled xdelta3 tool is missing.' }

$CurrentHash = (Get-FileHash -LiteralPath $GamePck -Algorithm SHA256).Hash
if ($CurrentHash -eq $FinalHash) {
    Write-Host 'The v1.2 localization is already installed.' -ForegroundColor Green
    exit 0
}
if (-not $BridgePatches.ContainsKey($CurrentHash) -and -not $DirectPatches.ContainsKey($CurrentHash)) {
    throw "This updater requires a supported earlier localized PCK, found $CurrentHash. Vanilla users must install the complete package."
}

$DriveName = [IO.Path]::GetPathRoot($GameDirectory).TrimEnd('\').TrimEnd(':')
$Drive = Get-PSDrive -Name $DriveName
$TemporaryCopies = if ($BridgePatches.ContainsKey($CurrentHash)) { 2 } else { 1 }
$Required = ((Get-Item -LiteralPath $GamePck).Length * $TemporaryCopies) + 1GB
if ($Drive.Free -lt $Required) {
    throw ('Not enough free disk space. At least {0:N1} GB is required during installation.' -f ($Required / 1GB))
}

foreach ($temporary in @($BridgeTemporary, $FinalTemporary)) {
    if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force }
}
if (-not (Test-Path -LiteralPath $Backup)) {
    try {
        New-Item -ItemType HardLink -Path $Backup -Target $GamePck -ErrorAction Stop | Out-Null
    } catch {
        if ($Drive.Free -lt ($Required + (Get-Item -LiteralPath $GamePck).Length)) {
            throw 'The backup could not use a hard link, and there is not enough free space to copy it.'
        }
        Copy-Item -LiteralPath $GamePck -Destination $Backup
    }
}
$BackupHash = (Get-FileHash -LiteralPath $Backup -Algorithm SHA256).Hash
if ($BackupHash -ne $CurrentHash) { throw "Existing update backup hash is unexpected: $BackupHash" }

try {
    $PatchSource = $GamePck
    $PatchSourceHash = $CurrentHash
    if ($BridgePatches.ContainsKey($CurrentHash)) {
        $BridgePatch = Join-Path $PSScriptRoot (Join-Path 'patch' $BridgePatches[$CurrentHash])
        if (-not (Test-Path -LiteralPath $BridgePatch)) { throw 'The matching bridge patch is missing.' }
        Write-Host 'Preparing the supported earlier localization for the v1.2 update...'
        Apply-XdeltaPatch -Source $GamePck -Patch $BridgePatch -Destination $BridgeTemporary
        $BridgeHash = (Get-FileHash -LiteralPath $BridgeTemporary -Algorithm SHA256).Hash
        if ($BridgeHash -ne $IntermediateHash) { throw "Bridge verification failed: $BridgeHash" }
        $PatchSource = $BridgeTemporary
        $PatchSourceHash = $IntermediateHash
    }

    $FinalPatch = Join-Path $PSScriptRoot (Join-Path 'patch' $DirectPatches[$PatchSourceHash])
    if (-not (Test-Path -LiteralPath $FinalPatch)) { throw 'The matching v1.2 patch is missing.' }
    Write-Host 'Applying the v1.2 localization update...'
    Apply-XdeltaPatch -Source $PatchSource -Patch $FinalPatch -Destination $FinalTemporary
    $BuiltHash = (Get-FileHash -LiteralPath $FinalTemporary -Algorithm SHA256).Hash
    if ($BuiltHash -ne $FinalHash) { throw "Verification failed. Expected $FinalHash, built $BuiltHash." }
    Move-Item -LiteralPath $FinalTemporary -Destination $GamePck -Force
} finally {
    foreach ($temporary in @($BridgeTemporary, $FinalTemporary)) {
        if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force }
    }
}

Write-Host 'The v1.2 text update was installed successfully.' -ForegroundColor Green
